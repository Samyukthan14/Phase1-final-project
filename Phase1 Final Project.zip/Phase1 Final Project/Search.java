package virtualkeyPackage;
import java.io.File;

public class Search {
	protected static void searchFile(String fileToBeSearched) {
        File file = new File(fileToBeSearched);
        
	     if(file.exists())
	     {
		     System.out.println("File found\n");
	     }
	     else
	     {
              System.out.println(" File not found\n");
	     }	
    }
}
