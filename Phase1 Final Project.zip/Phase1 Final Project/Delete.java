package virtualkeyPackage;
import java.io.File;

public class Delete {
	protected static void deleteFile(String fileToBeDeleted) {
		File file = new File(fileToBeDeleted);
				
				if(file.exists()) {
					if ( file.delete() ) {
		          	System.out.println("File is deleted successfully\n");
					}
				}
				else 
				{
			       System.out.println("File not found\n");
				}
			}
}