package virtualkeyPackage;
import java.io.File;
import java.io.IOException;

public class Create {
	protected static void createFile (String nameOfTheFile) {
		File file = new File(nameOfTheFile);
		
		try {
			if (file.createNewFile() ) {
				System.out.println("File Created Successfully\n");
			} else {
				System.out.println("File already exists\n");
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}