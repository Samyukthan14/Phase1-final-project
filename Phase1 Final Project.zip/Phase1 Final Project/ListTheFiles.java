package virtualkeyPackage;
import java.io.File;
import java.util.ArrayList;

public class ListTheFiles {
		protected static String[] sort(String array[], int size){
			String flag;
			for(int i=0; i<size; i++){
				for(int j=1; j<(size-i); j++){
					if(array[j-1].compareToIgnoreCase(array[j])>0){
						flag = array[j-1];
						array[j-1]=array[j];
						array[j]=flag;
					}
				}
			}
			return array;
		}
		
		protected static void listFiles() {
			
			int c = 0;
		    ArrayList<String> fileName = new ArrayList<String>();
	        File path = new File(System.getProperty("user.dir"));
			File[] list = path.listFiles();
			c = list.length;
			
			
			System.out.println("Files in order: ");
			for (int i=0;i<c;i++) {
			  if (list[i].isFile()) {
			   fileName.add(list[i].getName());
			  } 
			}
			
			String[] names = new String[fileName.size()];
			 
		   for (int i = 0; i < fileName.size(); i++) {
		        names[i] = fileName.get(i);
		    }
			
		    String[] orderedNames = sort(names, names.length);
			
			for(String currentFile: orderedNames) {
				System.out.println(currentFile);
			}
		}
}