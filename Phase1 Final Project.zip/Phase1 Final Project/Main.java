package virtualkeyPackage;
import java.util.Scanner;
import java.io.IOException;

public class Main {
	public static void main(String[] args) throws IOException {
		int option=0, operations=0;
		System.out.println("\t\t\t\t\t\t Welcome to Lockers Pvt.Ltd.");
		System.out.println("\nThe developer of the application is ABC.\n");
		
		Scanner sc =new Scanner(System.in);
		while(true)
		{
		System.out.println("Choose one of the Following options:");
		System.out.println("1. Retrive the Current Files");
		System.out.println("2. Business Operations Menu");
	    System.out.println("3. Close the  Application");
		
				option = sc.nextInt();
			
			switch(option)
			{
			case 1: 
				ListTheFiles.listFiles();
				break;
				
			case 2:
	            System.out.println("Please choose one of the following options:");
                System.out.println("1. Add a File");
            	System.out.println("2. Delete a File");
	            System.out.println("3. Search for a File");
                System.out.println("4. Close the Application");
		  
						 operations = sc.nextInt();
					
					switch(operations)
					{
					case 1:
						System.out.println("Enter the name of the file to be created:");
						String createFile;
						createFile = sc.next();
						Create.createFile(createFile);
						break;
						
					case 2:
						System.out.print("Enter the name of the file to be deleted: ");
						String deleteFile = sc.next();
						Delete.deleteFile(deleteFile);
						break;
						
					case 3:
						System.out.println("Enter the name of the file to be searched: ");
						String searchFile = sc.next();
						Search.searchFile(searchFile);
						break;
						
					case 4:
						sc.close();
						System.out.println("The application is closed");
						System.exit(0);
						
				default:
						System.out.println("\n Invalid Operation\n");
						break;
				}
					break;
					
			case 3:
				sc.close();
				System.out.println("\n Thank you!");
				System.exit(0);
				break;
			
			default:
                System.out.println("\nEnter a valid input\n");
				break;
			}	
		}
	}
}